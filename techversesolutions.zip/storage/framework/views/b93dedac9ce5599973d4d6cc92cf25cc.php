<div class="bg-indigo-700 text-white w-64 space-y-6 px-2 py-4 absolute inset-y-0 left-0 transform -translate-x-full md:relative md:translate-x-0 transition duration-200 ease-in-out" id="sidebar">
    <div class="flex items-center space-x-2 px-4">
        <svg xmlns="http://www.w3.org/2000/svg" class="h-8 w-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
        </svg>
        <span class="text-2xl font-extrabold"><?php echo e(config('app.name')); ?></span>
    </div>
    
    <nav>
        <?php
            $currentRoute = request()->route()->getName();
            $menuItems = [
                [
                    'route' => 'user.pages.dashboard',
                    'icon' => 'M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6',
                    'label' => 'Dashboard',
                    'active' => request()->routeIs('user.pages.dashboard'),
                ],
                [
                    'route' => 'user.pages.dashboard',
                    'icon' => 'M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z',
                    'label' => 'Users',
                    'active' => str_starts_with($currentRoute, 'users.'),
                ],
                // Add more menu items as needed
            ];
        ?>

        <?php $__currentLoopData = $menuItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="<?php echo e(route($item['route'])); ?>" 
               class="block py-2.5 px-4 rounded transition duration-200 <?php echo e($item['active'] ? 'bg-indigo-600 text-white' : 'hover:bg-indigo-600 hover:text-white'); ?>">
                <span class="flex items-center space-x-2">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="<?php echo e($item['icon']); ?>" />
                    </svg>
                    <span><?php echo e($item['label']); ?></span>
                </span>
            </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </nav>
</div><?php /**PATH /Users/susant/Desktop/techverse_laravel_project/resources/views/user/layout/sidebar.blade.php ENDPATH**/ ?>