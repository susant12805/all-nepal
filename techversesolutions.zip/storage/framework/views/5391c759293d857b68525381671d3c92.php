<?php $__env->startSection('title', 'Services Management'); ?>
<?php $__env->startSection('header', 'Services Management'); ?>

<?php $__env->startSection('content'); ?>
<style>
/* Custom Styles */
    .card {
        border: 1px solid rgba(0,0,0,0.1);
        transition: transform 0.2s ease, box-shadow 0.2s ease;
    }
    
    .empty-state {
        max-width: 400px;
        margin: 0 auto;
    }
    
    .table th {
        font-weight: 600;
        text-transform: uppercase;
        font-size: 0.75rem;
        letter-spacing: 0.5px;
        color: #6c757d;
        border-bottom-width: 2px;
    }
    
    .badge {
        font-weight: 500;
        padding: 0.35em 0.65em;
    }
    
    .modal-header {
        border-bottom: 1px solid rgba(0,0,0,0.1);
    }
    
    .modal-footer {
        border-top: 1px solid rgba(0,0,0,0.1);
    }
    
    #imagePreview img {
        max-width: 100%;
        max-height: 150px;
        border-radius: 0.5rem;
        border: 1px dashed #dee2e6;
        padding: 0.5rem;
    }
    
    /* Mobile Responsive */
    @media (max-width: 767.98px) {
        .table-responsive {
            border: none;
        }
        
        .table thead {
            display: none;
        }
        
        .table tbody tr {
            display: block;
            margin-bottom: 1rem;
            border-radius: 0.5rem;
            overflow: hidden;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }
        
        .table tbody td {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 0.75rem;
            border-bottom: 1px solid #f0f0f0;
        }
        
        .table tbody td::before {
            content: attr(data-label);
            font-weight: 600;
            margin-right: 1rem;
            color: #6c757d;
        }
        
        .table tbody td:last-child {
            border-bottom: none;
        }
    }
</style>
<div class="container-fluid px-4 py-3">
    <!-- Header Section -->
    <div class="d-flex flex-column flex-md-row justify-content-between align-items-center mb-4">
        <div class="mb-3 mb-md-0">
            <h1 class="h3 fw-bold text-primary">
                <i class="fas fa-concierge-bell me-2"></i>Services Management
            </h1>
            <p class="text-muted mb-0">Manage your services and offerings</p>
        </div>
        <button class="btn btn-primary shadow-sm" data-bs-toggle="modal" data-bs-target="#serviceModal">
            <i class="fas fa-plus me-2"></i>Create New Service
        </button>
    </div>

    <!-- Empty State (when no services exist) -->
    <?php if($services->isEmpty()): ?>
    <div class="card border-0 shadow-sm rounded-lg">
        <div class="card-body text-center py-5">
            <div class="empty-state">
                <i class="fas fa-box-open fa-4x text-muted mb-4"></i>
                <h3 class="h5 mb-3">No Services Found</h3>
                <p class="text-muted mb-4">You haven't created any services yet</p>
                <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#serviceModal">
                    <i class="fas fa-plus me-2"></i>Create Your First Service
                </button>
            </div>
        </div>
    </div>
    <?php else: ?>
    <!-- Services Table -->
    <div class="card border-0 shadow-sm rounded-lg overflow-hidden">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead class="bg-light">
                    <tr>
                        <th class="ps-4">Order</th>
                        <th>Image</th>
                        <th>Name</th>
                        <th>Description</th>
                        <th>Status</th>
                        <th class="pe-4 text-end">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="ps-4"><?php echo e($service->order); ?></td>
                        <td>
                            <?php if($service->image): ?>
                                <img src="<?php echo e(asset('storage/' . $service->image)); ?>" 
                                     class="rounded" 
                                     width="50" 
                                     height="50" 
                                     style="object-fit: cover"
                                     alt="<?php echo e($service->name); ?>">
                            <?php elseif($service->icon): ?>
                                <div class="bg-light rounded d-flex align-items-center justify-content-center" 
                                     style="width: 50px; height: 50px">
                                    <i class="<?php echo e($service->icon); ?> text-primary"></i>
                                </div>
                            <?php else: ?>
                                <div class="bg-light rounded d-flex align-items-center justify-content-center" 
                                     style="width: 50px; height: 50px">
                                    <i class="fas fa-image text-muted"></i>
                                </div>
                            <?php endif; ?>
                        </td>
                        <td class="fw-bold"><?php echo e($service->name); ?></td>
                        <td class="text-muted"><?php echo e(Str::limit($service->short_description, 50)); ?></td>
                        <td>
                            <span class="badge rounded-pill bg-<?php echo e($service->is_active ? 'success' : 'danger'); ?>">
                                <?php echo e($service->is_active ? 'Active' : 'Inactive'); ?>

                            </span>
                        </td>
                        <td class="pe-4 text-end">
                            <div class="btn-group">
                                <button class="btn btn-sm btn-outline-primary edit-service"
                                        data-service-id="<?php echo e($service->id); ?>"
                                        data-bs-toggle="tooltip"
                                        title="Edit">
                                    <i class="fas fa-edit"></i>
                                </button>
                                <form action="<?php echo e(route('user.services.destroy', $service->id)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" 
                                            class="btn btn-sm btn-outline-danger"
                                            data-bs-toggle="tooltip"
                                            title="Delete"
                                            onclick="return confirm('Are you sure?')">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </form>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
    <?php endif; ?>
</div>

<!-- Create/Edit Service Modal -->
<div class="modal fade" id="serviceModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header bg-light">
                <h5 class="modal-title" id="modalTitle">Create New Service</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form id="serviceForm" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div id="formMethod"></div>
                
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="name" class="form-label">Service Name <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="name" name="name" required>
                        </div>
                        
                        <div class="col-md-6 mb-3">
                            <label for="order" class="form-label">Display Order</label>
                            <input type="number" class="form-control" id="order" name="order" value="0">
                        </div>
                        
                        <div class="col-12 mb-3">
                            <label for="short_description" class="form-label">Short Description <span class="text-danger">*</span></label>
                            <textarea class="form-control" id="short_description" name="short_description" rows="2" maxlength="160" required></textarea>
                            <small class="text-muted">Max 160 characters</small>
                        </div>
                        
                        <div class="col-12 mb-3">
                            <label for="description" class="form-label">Full Description</label>
                            <textarea class="form-control" id="description" name="description" rows="4"></textarea>
                        </div>
                        
                        <div class="col-md-6 mb-3">
                            <label for="image" class="form-label">Service Image</label>
                            <div class="input-group">
                                <input type="file" class="form-control" id="image" name="image" accept="image/*">
                                <button class="btn btn-outline-secondary" type="button" id="clearImage">
                                    <i class="fas fa-times"></i>
                                </button>
                            </div>
                            <small class="text-muted">Recommended size: 800x600px</small>
                            <div id="imagePreview" class="mt-2 text-center"></div>
                        </div>
                        
                        <div class="col-md-6 mb-3">
                            <label for="icon" class="form-label">Icon Class (Font Awesome)</label>
                            <div class="input-group">
                                <span class="input-group-text"><i class="fas fa-icons"></i></span>
                                <input type="text" class="form-control" id="icon" name="icon" placeholder="fas fa-cog">
                            </div>
                            <small class="text-muted">e.g. fas fa-server, fas fa-cloud</small>
                        </div>
                        
                        <div class="col-md-6 mb-3">
                            <div class="form-check form-switch">
                                <input class="form-check-input" type="checkbox" id="is_active" name="is_active" value="1" checked>
                                <label class="form-check-label" for="is_active">Active Service</label>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer bg-light">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Save Service</button>
                </div>
            </form>
        </div>
    </div>
</div>


<?php $__env->startPush('scripts'); ?>

     <script src="<?php echo e(asset('js/app.js')); ?>">
    document.addEventListener('DOMContentLoaded', function() {
        // Initialize tooltips
        var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
        var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
            return new bootstrap.Tooltip(tooltipTriggerEl)
        });
        
        // Image preview functionality
        const imageInput = document.getElementById('image');
        const imagePreview = document.getElementById('imagePreview');
        const clearImageBtn = document.getElementById('clearImage');
        
        if (imageInput) {
            imageInput.addEventListener('change', function(e) {
                const file = e.target.files[0];
                if (file) {
                    const reader = new FileReader();
                    reader.onload = function(event) {
                        imagePreview.innerHTML = `<img src="${event.target.result}" class="img-fluid" alt="Preview">`;
                    };
                    reader.readAsDataURL(file);
                }
            });
        }
        
        if (clearImageBtn) {
            clearImageBtn.addEventListener('click', function() {
                imageInput.value = '';
                imagePreview.innerHTML = '';
            });
        }
        
        // Edit service functionality
        const editButtons = document.querySelectorAll('.edit-service');
        editButtons.forEach(button => {
            button.addEventListener('click', function() {
                const serviceId = this.getAttribute('data-service-id');
                fetch(`/user/services/${serviceId}/edit`)
                    .then(response => response.json())
                    .then(data => {
                        document.getElementById('modalTitle').textContent = 'Edit Service';
                        document.getElementById('formMethod').innerHTML = '<input type="hidden" name="_method" value="PUT">';
                        document.getElementById('serviceForm').action = `/user/services/${serviceId}`;
                        
                        // Populate form fields
                        document.getElementById('name').value = data.name;
                        document.getElementById('order').value = data.order;
                        document.getElementById('short_description').value = data.short_description;
                        document.getElementById('description').value = data.description;
                        document.getElementById('icon').value = data.icon;
                        document.getElementById('is_active').checked = data.is_active;
                        
                        if (data.image_url) {
                            imagePreview.innerHTML = `<img src="${data.image_url}" class="img-fluid" alt="Current Image">`;
                        }
                        
                        // Show modal
                        const modal = new bootstrap.Modal(document.getElementById('serviceModal'));
                        modal.show();
                    });
            });
        });
        
        // Reset form when modal is hidden
        document.getElementById('serviceModal').addEventListener('hidden.bs.modal', function () {
            document.getElementById('serviceForm').reset();
            document.getElementById('formMethod').innerHTML = '';
            document.getElementById('modalTitle').textContent = 'Create New Service';
            document.getElementById('serviceForm').action = "<?php echo e(route('user.services.store')); ?>";
            imagePreview.innerHTML = '';
        });
    });
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/susant/Desktop/techverse_laravel_project/resources/views/user/pages/services/service.blade.php ENDPATH**/ ?>