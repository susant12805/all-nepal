<div class="relative">
    <button id="userMenuButton" class="flex items-center space-x-2 focus:outline-none">
        <img class="h-8 w-8 rounded-full" src="<?php echo e(Auth::user()->avatar_url ?? 'https://ui-avatars.com/api/?name='.urlencode(Auth::user()->name)); ?>" alt="User profile">
        <span class="text-gray-700"><?php echo e(Auth::user()->name); ?></span>
    </button>
    <div id="userMenu" class="hidden absolute right-0 mt-2 w-48 bg-white rounded-md shadow-lg py-1 z-10">
        <a href="<?php echo e(route('profile.edit')); ?>" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">Your Profile</a>
        <a href="#" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">Settings</a>
        <form method="POST" action="<?php echo e(route('logout')); ?>">
            <?php echo csrf_field(); ?>
            <button type="submit" class="block w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">Sign out</button>
        </form>
    </div>
</div><?php /**PATH /Users/susant/Desktop/techverse_laravel_project/resources/views/user/layout/user-menu.blade.php ENDPATH**/ ?>