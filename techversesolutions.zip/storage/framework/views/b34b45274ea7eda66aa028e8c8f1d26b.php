<?php $__env->startSection('content'); ?>

    <!-- Projects Header -->
    <header class="projects-header">
        <div class="container">
            <h1>Our Projects</h1>
            <p>Discover our portfolio of innovative solutions that have helped clients achieve their business goals</p>
        </div>
    </header>

    <!-- Projects Section -->
    <section class="projects-section">
        <div class="container">
            <!-- Filter Buttons -->
            <div class="project-filters">
                <button class="filter-btn active" data-filter="all">All Projects</button>
                <button class="filter-btn" data-filter="web">Web Applications</button>
                <button class="filter-btn" data-filter="mobile">Mobile Apps</button>
                <button class="filter-btn" data-filter="iot">IoT Solutions</button>
                <button class="filter-btn" data-filter="ai">AI/ML Projects</button>
            </div>

            <!-- Projects Grid -->
            <div class="projects-container">
                <!-- Project 1 -->
                <div class="project-detail" id="project1" data-category="web ai">
                    <div class="project-content">
                        <div class="project-info">
                            <span class="project-category">Web Application / AI</span>
                            <h2>Enterprise SaaS Platform</h2>
                            <p class="project-subtitle">Revolutionizing enterprise resource management</p>
                            
                            <div class="project-description">
                                <p>We developed a comprehensive SaaS platform that integrates all aspects of enterprise resource planning into a single, intuitive interface. The solution includes:</p>
                                <ul>
                                    <li>AI-powered predictive analytics for inventory and supply chain</li>
                                    <li>Automated workflow management with smart routing</li>
                                    <li>Real-time collaboration tools for distributed teams</li>
                                    <li>Customizable dashboards with drill-down capabilities</li>
                                </ul>
                                <p>The platform reduced operational costs by 32% and improved decision-making speed by 45% for our client, a Fortune 500 manufacturing company.</p>
                            </div>
                            
                            <div class="project-tech">
                                <h4>Technologies Used:</h4>
                                <div class="tech-tags">
                                    <span>React</span>
                                    <span>Node.js</span>
                                    <span>TensorFlow</span>
                                    <span>AWS</span>
                                    <span>MongoDB</span>
                                </div>
                            </div>
                            
                            <a href="#" class="btn">Visit Website</a>
                        </div>
                        <div class="project-gallery">
                            <div class="main-image">
                                <img src="https://images.pexels.com/photos/6956414/pexels-photo-6956414.jpeg" alt="Enterprise SaaS Platform Screenshot">
                            </div>
                            <!-- <div class="thumbnail-grid">
                                <img src="images/project1-thumb1.jpg" alt="Dashboard View">
                                <img src="images/project1-thumb2.jpg" alt="Analytics View">
                                <img src="images/project1-thumb3.jpg" alt="Mobile View">
                            </div> -->
                        </div>
                    </div>
                    <div class="project-stats">
                        <div class="stat-item">
                            <h4>75%</h4>
                            <p>Reduction in manual processes</p>
                        </div>
                        <div class="stat-item">
                            <h4>45%</h4>
                            <p>Faster decision making</p>
                        </div>
                        <div class="stat-item">
                            <h4>99.9%</h4>
                            <p>Uptime reliability</p>
                        </div>
                    </div>
                </div>

                <!-- Project 2 -->
                <div class="project-detail" id="project2" data-category="mobile">
                    <div class="project-content">
                        <div class="project-info">
                            <span class="project-category">Mobile Application</span>
                            <h2>Mobile Banking App</h2>
                            <p class="project-subtitle">Secure financial management in your pocket</p>
                            
                            <div class="project-description">
                                <p>Our team designed and developed a next-generation mobile banking application for a leading financial institution. Key features include:</p>
                                <ul>
                                    <li>Biometric authentication (Face ID, Fingerprint)</li>
                                    <li>Real-time transaction notifications</li>
                                    <li>AI-powered spending insights and budgeting tools</li>
                                    <li>Peer-to-peer payments with QR code support</li>
                                    <li>24/7 virtual assistant for customer support</li>
                                </ul>
                                <p>The app achieved a 4.8-star rating in app stores and increased customer engagement by 60% within the first three months of launch.</p>
                            </div>
                            
                            <div class="project-tech">
                                <h4>Technologies Used:</h4>
                                <div class="tech-tags">
                                    <span>Flutter</span>
                                    <span>Dart</span>
                                    <span>Firebase</span>
                                    <span>Node.js</span>
                                    <span>Machine Learning</span>
                                </div>
                            </div>
                            
                            <div class="app-links">
                                <a href="#" class="btn"><i class="fab fa-apple"></i> App Store</a>
                                <a href="#" class="btn"><i class="fab fa-google-play"></i> Play Store</a>
                            </div>
                        </div>
                        <div class="project-gallery">
                            <div class="main-image">
                                <img src="https://images.pexels.com/photos/6956414/pexels-photo-6956414.jpeg" alt="Mobile Banking App Screenshots">
                            </div>
                            <!-- <div class="thumbnail-grid">
                                <img src="images/project2-thumb1.jpg" alt="Login Screen">
                                <img src="images/project2-thumb2.jpg" alt="Dashboard">
                                <img src="images/project2-thumb3.jpg" alt="Transaction History">
                            </div> -->
                        </div>
                    </div>
                    <div class="project-stats">
                        <div class="stat-item">
                            <h4>1M+</h4>
                            <p>Downloads in first month</p>
                        </div>
                        <div class="stat-item">
                            <h4>4.8/5</h4>
                            <p>Average rating</p>
                        </div>
                        <div class="stat-item">
                            <h4>60%</h4>
                            <p>Increase in engagement</p>
                        </div>
                    </div>
                </div>

                <!-- Project 3 -->
                <div class="project-detail" id="project3" data-category="iot">
                    <div class="project-content">
                        <div class="project-info">
                            <span class="project-category">IoT Solution</span>
                            <h2>Smart Home Automation System</h2>
                            <p class="project-subtitle">Intelligent living powered by IoT</p>
                            
                            <div class="project-description">
                                <p>We created a comprehensive smart home ecosystem that integrates all home devices into a single, AI-controlled platform. The system features:</p>
                                <ul>
                                    <li>Energy optimization algorithms that reduce consumption by up to 30%</li>
                                    <li>Voice control integration with major assistants (Alexa, Google)</li>
                                    <li>Predictive automation based on user habits</li>
                                    <li>Advanced security with facial recognition and anomaly detection</li>
                                    <li>Modular design that supports 200+ devices from different manufacturers</li>
                                </ul>
                                <p>The solution has been deployed in over 50,000 homes across North America and Europe, with customer satisfaction scores consistently above 95%.</p>
                            </div>
                            
                            <div class="project-tech">
                                <h4>Technologies Used:</h4>
                                <div class="tech-tags">
                                    <span>Python</span>
                                    <span>TensorFlow</span>
                                    <span>MQTT</span>
                                    <span>React Native</span>
                                    <span>AWS IoT</span>
                                </div>
                            </div>
                            
                            <a href="#" class="btn">Product Website</a>
                        </div>
                        <div class="project-gallery">
                            <div class="main-image">
                                <img src="https://images.pexels.com/photos/6956414/pexels-photo-6956414.jpeg" alt="Smart Home System">
                            </div>
                            <!-- <div class="thumbnail-grid">
                                <img src="images/project3-thumb1.jpg" alt="Mobile App">
                                <img src="images/project3-thumb2.jpg" alt="Control Panel">
                                <img src="images/project3-thumb3.jpg" alt="Device Integration">
                            </div> -->
                        </div>
                    </div>
                    <div class="project-stats">
                        <div class="stat-item">
                            <h4>50K+</h4>
                            <p>Homes automated</p>
                        </div>
                        <div class="stat-item">
                            <h4>30%</h4>
                            <p>Energy savings</p>
                        </div>
                        <div class="stat-item">
                            <h4>95%</h4>
                            <p>Satisfaction rate</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Testimonials Section -->

    <!-- CTA Section -->
    <section class="project-cta">
        <div class="container">
            <h2>Ready to Start Your Project?</h2>
            <p>Let's discuss how we can help you achieve your business goals with cutting-edge technology solutions.</p>
            <a href="contact.html" class="btn">Get in Touch</a>
        </div>
    </section>

    
    <script src="<?php echo e(asset('js/script.js')); ?>"></script>
    <script src="<?php echo e(asset('js/project.js')); ?>"></script>
<<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layout.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/susant/Desktop/techverse_laravel_project/resources/views/frontend/pages/projects.blade.php ENDPATH**/ ?>