<?php $__env->startSection('content'); ?>

    <!-- Page Header -->
    <section class="page-header">
        <div class="container">
            <div class="page-header-content">
                <h1>Contact Us</h1>
                <p>Get in touch with our team for any questions or support</p>
                <nav class="breadcrumb">
                    <a href="index.html">Home</a>
                    <span>/</span>
                    <span>Contact</span>
                </nav>
            </div>
        </div>
    </section>

    <!-- Contact Section -->
    <section class="contact-section">
        <div class="container">
            <div class="contact-layout">
                <!-- Contact Information -->
                <div class="contact-info-section">
                    <h2>Get In Touch</h2>
                    <p>We're here to help! Reach out to us through any of the following channels.</p>
                    <div class="contact-methods">
                        <div class="contact-method">
                            <div class="method-icon">
                                <i class="fas fa-map-marker-alt"></i>
                            </div>
                            <div class="method-info">
                                <h4>Visit Our Office</h4>
                                <p><?php echo e($logo->address); ?></p>
                            </div>
                        </div>
                        
                        <div class="contact-method">
                            <div class="method-icon">
                                <i class="fas fa-phone"></i>
                            </div>
                            <div class="method-info">
                                <h4>Call Us</h4>
                                <p><?php echo e($logo->phone1); ?>, <?php echo e($logo->phone2); ?></p>
                            </div>
                        </div>
                        
                        <div class="contact-method">
                            <div class="method-icon">
                                <i class="fas fa-envelope"></i>
                            </div>
                            <div class="method-info">
                                <h4>Email Us</h4>
                                <p><?php echo e($logo->email); ?></p>
                            </div>
                        </div>
                        
                        <div class="contact-method">
                            <div class="method-icon">
                                <i class="fas fa-clock"></i>
                            </div>
                            <div class="method-info">
                                <h4>Business Hours</h4>
                                <p>Mon-Fri: 9:00 AM - 7:00 PM<br>Sat: 10:00 AM - 5:00 PM<br>Sun: Closed</p>
                            </div>
                        </div>
                    </div>
                    
                </div>

                <!-- Contact Form -->
                <div class="form-column col-md-6 col-sm-12 col-xs-12">
                    	
                        <!-- Comment Form -->
                        <div class="contact-form">
                           

                             <?php if(session('success')): ?>
                                <div class="alert alert-success alert-dismissible show" role="alert">
                                    <?php echo e(session('success')); ?>

                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                            <?php endif; ?>


                                
                        </div>
                        <!--End Comment Form --> 
                        
                    </div>
            </div>
        </div>
    </section>

    <!-- Map Section -->
    <section class="map-section">
        <div class="container">
            <div class="section-header">
                <h2>Find Us</h2>
                <p>Visit our store for hands-on product demonstrations and expert consultation</p>
            </div>
            <div class="map-container">
                <div class="map-placeholder">
                    <i class="fas fa-map-marked-alt"></i>
                    <h3>Interactive Map</h3>
                    <p>Kathmandu, Lazimpat</p>
                        <i class="fas fa-external-link-alt"><?php echo $logo->map; ?></i>
                        Open in Google Maps
                    </a>
                </div>
            </div>
        </div>
    </section>

    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('bottomscript'); ?>
<!-- <script src="<?php echo e(asset('js/script.js')); ?>"></script> -->
<script src="<?php echo e(asset('js/contact.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layout.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/tiktokne/techversesolutionspvtltd.com/resources/views/frontend/pages/contact.blade.php ENDPATH**/ ?>