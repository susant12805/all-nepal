<?php $__env->startSection('content'); ?>

<section class="section services-section">
    <div class="container">
        <h2 class="section-title">Our Comprehensive IT Services</h2>
        <div class="features-grid">

            <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="feature-item">
                <div class="feature-icon">
                    <i class="fas fa-award"></i>
                </div>
                <h2><?php echo e($service->name); ?></h2>
                <h3><?php echo e($service->short_description); ?></h3>
                <h3><?php echo e($service->description); ?></h3>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('bottomscript'); ?>
<script src="<?php echo e(asset('js/service.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layout.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/tiktokne/techversesolutionspvtltd.com/resources/views/frontend/pages/service.blade.php ENDPATH**/ ?>