	<!-- Back to top -->
	<a href="#top" id="back-to-top"><i class="fa fa-angle-up"></i></a>

	<!-- Ansta Scripts -->
	<!-- Core -->
	<script src="<?php echo e(asset('backend')); ?>/assets/plugins/jquery/dist/jquery.min.js"></script>
	<script src="<?php echo e(asset('backend')); ?>/assets/js/popper.js"></script>
	<script src="<?php echo e(asset('backend')); ?>/assets/plugins/bootstrap/js/bootstrap.min.js"></script>
	<script src="<?php echo e(asset('backend')); ?>/assets/plugins/chart-circle/circle-progress.min.js"></script>

	<!-- Optional JS -->
	<script src="<?php echo e(asset('backend')); ?>/assets/plugins/chart.js/dist/Chart.min.js"></script>
	<script src="<?php echo e(asset('backend')); ?>/assets/plugins/chart.js/dist/Chart.extension.js"></script>

	<!-- Echarts JS -->
	<script src="<?php echo e(asset('backend')); ?>/assets/plugins/chart-echarts/echarts.js"></script>

	<!-- Fullside-menu Js-->
	<script src="<?php echo e(asset('backend')); ?>/assets/plugins/toggle-sidebar/js/sidemenu.js"></script>

	<!-- Custom scroll bar Js-->
	<script src="<?php echo e(asset('backend')); ?>/assets/plugins/customscroll/jquery.mCustomScrollbar.concat.min.js"></script>
	<script src="<?php echo e(asset('backend')); ?>/assets/js/dashboard-it.js"></script>
	<!-- Ansta JS -->
	<script src="<?php echo e(asset('backend')); ?>/assets/js/custom.js"></script>
<?php /**PATH /Users/susant/Desktop/techverse_laravel_project/resources/views/user/layouts/footer.blade.php ENDPATH**/ ?>