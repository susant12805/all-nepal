
<nav class="navbar" id="navbar">
    <div class="nav-container">
        <div class="nav-logo">
            <i class="fas fa-microchip"></i>
            <span><a href="{{ url('/home') }}">Tech Verse</a></span>
        </div>
        <div class="nav-menu" id="nav-menu">
            <a href="{{ url('/home') }}" class="nav-link {{ Request::is('/') ? 'active' : '' }}">Home</a>
            <a href="{{ url('/service') }}" class="nav-link {{ Request::is('service') ? 'active' : '' }}">Service</a>
            <a href="{{ url('/product') }}" class="nav-link {{ Request::is('product') ? 'active' : '' }}">Products</a>
            <a href="{{ url('/project') }}" class="nav-link {{ Request::is('project') ? 'active' : '' }}">Projects</a>
            <a href="{{ url('/about') }}" class="nav-link {{ Request::is('about') ? 'active' : '' }}">About</a>
            <a href="{{ url('/contact') }}" class="nav-link {{ Request::is('contact') ? 'active' : '' }}">Contact</a>
        </div>
    </div>
</nav>