@extends('frontend.layout.app')
@section('content')

<!-- Projects Header -->
<header class="projects-header">
    <div class="container">
        <h1>Our Projects</h1>
        <p>Discover our portfolio of innovative solutions that have helped clients achieve their business goals</p>
    </div>
</header>

<!-- Projects Section -->
<section class="projects-section">
    <div class="container">
        <!-- Filter Buttons -->
        <div class="project-filters">
            <button class="filter-btn active" data-filter="all">All Projects</button>
            <button class="filter-btn" data-filter="web">Web Applications</button>
            <button class="filter-btn" data-filter="mobile">Mobile Apps</button>
            <button class="filter-btn" data-filter="iot">IoT Solutions</button>
            <button class="filter-btn" data-filter="ai">AI/ML Projects</button>
        </div>

        <!-- Projects Grid -->
        <!--  Project 1 -->
        @foreach ($projects as $project)
        <div class="project-detail" id="project1" data-category="web ai">
            <div class="project-content">
                <div class="project-info">

                    <span class="project-category">{{$project->name}}I</span>
                    <p class="project-subtitle">{{$project->short_description}}</p>
                    <div class="project-description">
                        <p>{{$project->description}}</p>
                    </div>
                </div>
                <div class="project-gallery">
                    
                        @if($project->image)
                        <img src="{{ asset('storage/'.$project->image) }}" alt="{{ $project->name }}" class="main-image">
                        @elseif($project->icon)
                        <i class="{{ $project->icon }}"></i>
                        @else
                        <i class="fas fa-box"></i> <!-- Default icon -->
                        @endif
                </div>
            </div>
        </div>
        @endforeach



    </div>
</section> -->

<section class="project-cta">
    <div class="container">
        <h2>Ready to Start Your Project?</h2>
        <p>Let's discuss how we can help you achieve your business goals with cutting-edge technology solutions.</p>
        <a href="contact.html" class="btn">Get in Touch</a>
    </div>
</section>

@endsection
    @section('bottomscript')
<script src="{{ asset('js/project.js') }}"></script>
@endsection