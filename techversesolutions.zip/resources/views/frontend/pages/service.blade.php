@extends('frontend.layout.app')
@section('content')

<section class="section services-section">
    <div class="container">
        <h2 class="section-title">Our Comprehensive IT Services</h2>
        <div class="features-grid">

            @foreach ($services as $service)
            <div class="feature-item">
                <div class="feature-icon">
                    <i class="fas fa-award"></i>
                </div>
                <h2>{{ $service->name }}</h2>
                <h3>{{ $service->short_description }}</h3>
                <h3>{{ $service->description }}</h3>
            </div>
            @endforeach
        </div>
</section>
@endsection
@section('bottomscript')
<script src="{{ asset('js/service.js') }}"></script>
@endsection